# Copyright (C) 2006-2010 TOMITA Masahiro
# mailto:tommy@tmtm.org

module MailParser
  class ParseError < StandardError
  end
end
