# Copyright (C) 2006-2010 TOMITA Masahiro
# mailto:tommy@tmtm.org

require "mailparser/rfc2045"

class MailParser::RFC2183::Scanner < MailParser::RFC2045::Scanner
end
