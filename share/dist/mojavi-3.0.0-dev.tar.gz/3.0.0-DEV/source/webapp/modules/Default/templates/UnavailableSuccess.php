<?php require_once(MO_MODULE_DIR . '/Default/templates/includes/header.php'); ?>

<?php require_once(MO_MODULE_DIR . '/Default/templates/includes/footer.php'); ?>